package com.example.todolisttasya.usecases

import com.example.todolisttasya.entity.Todo
import com.google.firebase.Firebase
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.tasks.await

class TodoUseCase {
    private val db: FirebaseFirestore = Firebase.firestore

    suspend fun getTodo(): List<Todo> {
        val data = db.collection("todo")
            .get()
            .await()

        if (data.isEmpty) {
            throw Exception("Data di Server Kosong")
        }

        return data.documents.map {
            Todo(
                id = it.id,
                title = it.get("title").toString(),
                description = it.get("description").toString()
            )
        }
    }
}