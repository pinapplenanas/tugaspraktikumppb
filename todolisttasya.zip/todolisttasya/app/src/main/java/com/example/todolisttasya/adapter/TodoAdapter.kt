package com.example.todolisttasya.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.todolisttasya.databinding.ItemTodoBinding
import com.example.todolisttasya.entity.Todo
import com.google.firebase.firestore.core.View

class TodoAdapter(
   private val dataset: MutableList<Todo>
): RecyclerView.Adapter<TodoAdapter.CustomViewHolder>() {

    inner class CustomViewHolder(
        val view: ItemTodoBinding
    ): RecyclerView.ViewHolder(view.root) {

        fun bindData(data: Todo) {
            view.judul.text = data.title
            view.deskripsi.text = data.description
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): CustomViewHolder {
        val binding= ItemTodoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )

        return CustomViewHolder(binding)
    }

    override fun onBindViewHolder(
        holder: CustomViewHolder,
        index: Int
    ) {
        val data = dataset[index]
        holder.bindData(data)
    }

    override fun getItemCount(): Int {
        return dataset.size
    }

    @SuppressLint("NotifyDataSetChanged")
    fun updateDataSet(data: List<Todo>) {
        dataset.clear()
        dataset.addAll(data)
        notifyDataSetChanged()
    }

}